import React from 'react'
import Navbar from '../components/Navbar';
import Banner from '../images/banner.jpg';

const Contact = () => {
  return (
    <div><Navbar /><h1>Contact Cats - Adoção de gatinhos</h1>
    <img src={Banner}></img>
<h3>Interessados entrar em contato :</h3>
<p>E-mail: contato@cats.org.br</p>
<p>ingridcavalli@gmail.com</p>
<p>isabelaguessi@gmail.com</p>
<p>adryelly@gmail.com</p>
<p>gabrielpinheiro@gmail.com</p>
<p>Biel@gmail.com</p>
    </div>
    
  )
}

export default Contact