import React from "react";
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import './routes.css';

const About = () => {
    return (
        <div>
            <Navbar />
            <div className="container">
                <h1>Sobre nós</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus nihil quaerat 
                    corporis atque voluptas maxime ea. Autem repellendus, maiores soluta mollitia 
                    illo pariatur reiciendis? Laudantium esse beatae minima veniam aspernatur!</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus nihil quaerat 
                    corporis atque voluptas maxime ea. Autem repellendus, maiores soluta mollitia 
                    illo pariatur reiciendis? Laudantium esse beatae minima veniam aspernatur!</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus nihil quaerat 
                    corporis atque voluptas maxime ea. Autem repellendus, maiores soluta mollitia 
                    illo pariatur reiciendis? Laudantium esse beatae minima veniam aspernatur!</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus nihil quaerat 
                    corporis atque voluptas maxime ea. Autem repellendus, maiores soluta mollitia 
                    illo pariatur reiciendis? Laudantium esse beatae minima veniam aspernatur!</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus nihil quaerat 
                    corporis atque voluptas maxime ea. Autem repellendus, maiores soluta mollitia 
                    illo pariatur reiciendis? Laudantium esse beatae minima veniam aspernatur!</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus nihil quaerat 
                    corporis atque voluptas maxime ea. Autem repellendus, maiores soluta mollitia 
                    illo pariatur reiciendis? Laudantium esse beatae minima veniam aspernatur!</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus nihil quaerat 
                    corporis atque voluptas maxime ea. Autem repellendus, maiores soluta mollitia 
                    illo pariatur reiciendis? Laudantium esse beatae minima veniam aspernatur!</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus nihil quaerat 
                    corporis atque voluptas maxime ea. Autem repellendus, maiores soluta mollitia 
                    illo pariatur reiciendis? Laudantium esse beatae minima veniam aspernatur!</p>
            </div>
            <Footer />
        </div>
    )
}

export default About