import React from 'react';
import './footer.css';

function Footer() {
    return(
        <footer>
            <p>Footer Lorem ipsum dolor sit amet consectetur 
            adipisicing elit. Natus a expedita velit hic, quas neque itaque facilis 
            libero ipsa? Itaque voluptatum fuga nihil est a animi esse voluptates sed. Facere?
            </p>
        </footer>
    );
}

export default Footer;