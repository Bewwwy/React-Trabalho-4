import React from "react";

const About = () => {
    return(
        <div><h1>Sobre nós</h1></div>
    )
}

export default About