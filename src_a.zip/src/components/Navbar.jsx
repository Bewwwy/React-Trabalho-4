import React from 'react';
import { Link } from 'react-router-dom';
import './navbar.css';
import gato from '../imgs/gato.png';
const Navbar = () => {
  return (
    <nav>
        <img src={gato} alt="Logo_gato" width="20rem" />
        <Link to="/">Home</Link>
        <Link to="/login">Login</Link>
        <Link to="/about">Sobre</Link>
        <Link to="/contact">Contato</Link>       
    </nav>
  )
}
export default Navbar